# DAMAC CFO Finance Co-Pilot v02 — Demo Talk Track

## How to use this document

Read the **High-level structure** first to understand the arc. Each act tells one story that builds on the last. Then go into the **Detailed acts** for the exact words, clicks, and CFO takeaways.

**Full demo:** ~23 minutes  
**Short slot (12 min):** Acts 1–3 only (stop after Precedent Comps)  
**Exec 5-min flash:** Opening → one voice demo on Football Field → Freeze Gate  

---

## High-level structure

| Act | Title | Tabs | Time | The one thing you prove |
|-----|-------|------|------|-------------------------|
| Opening | Set the scene | — | 2 min | This is not a spreadsheet |
| 1 | The Investment Case | Overview, Scenarios | 4 min | The returns clear the hurdle |
| 2 | What Is It Worth? | Valuation, WACC | 5 min | Four methods, one consensus |
| 3 | Build or Buy? | Build vs Buy, Comps | 4 min | Build wins on return, buy wins on speed |
| 4 | Is the Deal Clean? | QoE, Synergies, DD | 4 min | EBITDA is real, max bid is £X |
| 5 | Lock It Down | Evidence, Approval Gate | 3 min | Hash-locked, audit-safe, IC-ready |
| Closing | So what? | — | 1 min | One decision, one number |

---

## Detailed acts

---

### Opening — Set the scene (2 min)

**What you say:**

> "What you're looking at is a prototype of the CFO Finance Co-Pilot — an AI assistant that sits alongside the finance team during an Investment Committee process. Every number you see is computed in real-time from a deterministic finance engine. The AI doesn't guess — it runs the same DCF model your analysts would, but it does it in seconds and it can explain every assumption out loud."

> "We're going to walk through a 120-megawatt data centre investment that DAMAC is evaluating. The question on the table: is this worth doing, what's it worth, and can we get to an IC memo today rather than in three weeks?"

**What you click:** Nothing yet. Just the dashboard visible with the KPI strip (IRR, NPV, CAPEX, Risk Score) showing `--` — good visual tension.

**CFO takeaway:** The system replaces the three-week model build, not the analyst.

---

### Act 1 — The Investment Case (4 min)

**Tabs:** Overview → Scenarios

#### Step 1 — Overview tab (default)

**What you say:**

> "The base case is a 7-phase ramp from 18 MW in 2026 to 120 MW by 2032. AEDm 1,850 of phased CAPEX. Stabilisation by 2029. The headline IRR is 31.9% on an unlevered basis — well above the 12% hurdle."

**What you click:** Quick prompt → **"Does this beat the hurdle?"**

**What appears:** IRR and NPV KPIs populate. Recommendation panel shows the investment is APPROVED. Cash flow chart renders with the year-by-year FCF arc.

**What you say:**

> "The system also gives you the recommendation immediately — not just the number. And it flags the spread over hurdle. That's what a CFO needs on slide one."

#### Step 2 — Scenarios tab

**What you click:** Tab → **Scenarios** → click "Compare" button

**What appears:** Three-bar comparison (base / upside / downside) with IRR and NPV for each.

**What you say:**

> "Now let's stress it. Base case: 31.9% IRR. Downside — which assumes occupancy 15% below plan and power costs elevated — still comes in at 24%. Even the downside case clears the hurdle by 12 points. That's a very robust investment."

> "You can ask the voice agent to go deeper. Let me show you that."

**Voice prompt (speak aloud):** *"Stress test this investment case."*

**What appears:** Risk score updates, narrative explains the severe scenario, suggested follow-ups appear.

**CFO takeaway:** The downside IRR still beats the hurdle. This investment is resilient.

---

### Act 2 — What Is It Worth? (5 min)

**Tabs:** Valuation Methods → WACC / Capital

#### Step 1 — Football field

**What you click:** Tab → **Valuation Methods**

**What you say:**

> "IRR tells you the return you'll earn. Enterprise value tells you what someone would pay for this asset. These are two different questions. Let me show you the valuation from four angles simultaneously."

**Voice prompt (speak aloud):** *"Show me the football field across all four valuation methods."*

**What appears:** Horizontal SVG bar chart renders — four method rows (DCF, Trading Comps, Precedent Deals, Asset Replacement) each with a low-mid-high range bar. Consensus band overlays all four. EV KPI strip populates: ~AEDm 4,000 midpoint, ~AEDm 33/MW.

**What you say:**

> "This is the football field — the standard M&A presentation format. DCF is the most conservative because it penalises you for the 3-year construction drag before the asset is cashflow-positive. Trading comps and precedent deals are higher because they reflect the stabilised asset value that a buyer in the market would pay today."

> "The consensus midpoint is around AEDm 4,000. At 120 MW, that's AEDm 33 per megawatt of contracted capacity. We'll test that against real deals in a moment."

#### Step 2 — WACC

**What you click:** Tab → **WACC / Capital**

**Voice prompt (speak aloud):** *"Build the WACC from first principles."*

**What appears:** WACC component stack (risk-free rate → ERP → beta → cost of equity → debt cost → WACC at 10.5%), then the sensitivity grid showing EV impact per 50bps WACC move.

**What you say:**

> "The WACC we're using is 10.5%. It's built from a risk-free rate of 4.5%, equity risk premium of 6.5% applied to a 1.35 beta — appropriate for a construction-phase digital infrastructure asset in a developing market. Every 50 basis points of WACC adds or removes roughly AEDm 200–250 of enterprise value. That's the number you negotiate with the lenders."

**CFO takeaway:** Four methods, one consensus. The asset is worth ~AEDm 4,000 at stabilisation. WACC is the key lever.

---

### Act 3 — Build or Buy? (4 min)

**Tabs:** Build vs Buy → Precedent Comps

#### Step 1 — Build vs Buy

**What you click:** Tab → **Build vs Buy**

**What you say:**

> "The CFO's question isn't always 'should we build this?' Sometimes it's 'should we build it or just acquire an existing platform?' This module runs that comparison in seconds."

**Voice prompt (speak aloud):** *"Compare build versus buying an existing 35-megawatt data centre for AEDm 2,200."*

**What appears:** Two cards side by side — Build (Greenfield) and Buy (Acquisition) — each showing NPV, IRR, capex, time to revenue, execution risk. Decision matrix below with weighted scores. Recommendation banner.

**What you say:**

> "Build wins on return — 31.9% IRR versus 17% for the acquisition. But the acquisition gets to revenue in 6 months versus 30 months for the greenfield. The decision matrix weights these criteria and the system flags which one wins on a weighted basis."

> "Here's the interesting part — you can change the acquisition price in real-time. Watch what happens if we offer AEDm 1,600 instead."

**Voice prompt (speak aloud):** *"Compare build versus buying for AEDm 1,600."*

**What appears:** Buy NPV and IRR improve, recommendation may flip or the weighted delta changes.

**What you say:**

> "At AEDm 1,600, the acquisition starts to look more competitive. That gives you the maximum bid anchor immediately."

#### Step 2 — Precedent Comps

**What you click:** Tab → **Precedent Comps**

**Voice prompt (speak aloud):** *"Show me precedent M&A comps — where does DAMAC sit on EV per MW?"*

**What appears:** Table of 6 real deals (QTS/Blackstone, CyrusOne/KKR, Switch/DigitalBridge, EdgeConneX/EQT, Gulf Data Hub, DC7 MEA) with EV/EBITDA and EV/MW. DAMAC implied row highlighted in teal. Benchmark range panel shows premium/discount vs median.

**What you say:**

> "These are real transactions. The global median is around 22× EV/EBITDA. MENA comps — Gulf Data Hub and DC7 — trade at 16–18× because of the liquidity premium and emerging market discount. DAMAC at our implied 7.9× is actually at a discount to MENA comps — which means we're not overpaying if we're the buyer, or we have upside if we're the seller."

> "This is the kind of context that used to take a banker two weeks to compile. We have it in 30 seconds."

**CFO takeaway:** Build wins on return. Buy wins on speed. The MENA comps say DAMAC is undervalued versus the market.

---

### Act 4 — Is the Deal Clean? (4 min)

**Tabs:** Quality of Earnings → Synergy Model

> *Note: This act is most relevant for an acquisition scenario. Frame it as: "Assume we're proceeding with the buy option — here's what due diligence looks like."*

#### Step 1 — Quality of Earnings

**What you click:** Tab → **Quality of Earnings**

**Voice prompt (speak aloud):** *"Run quality of earnings — what one-time items are inflating the EBITDA?"*

**What appears:** Waterfall bridge chart: Reported EBITDA → adjustments (pre-opening costs, management fee, power hedge gain, working capital) → Normalised EBITDA. Quality score badge. Adjustment table with amounts. Debt-like items (AEDm 102 total).

**What you say:**

> "The reported EBITDA has some one-time items in it. Pre-opening costs are an addback — they were expensed but won't recur. The power hedging gain is a deduction — it was real cash but it's not part of the run-rate business. After normalisation, EBITDA drops by about AEDm 18. That moves the enterprise value by AEDm 170 at 9.5× exit."

> "And then there are debt-like items — AEDm 102 in construction warranties and finance leases — that come off the bid price at closing. These numbers change the offer letter."

#### Step 2 — Synergy Model

**What you click:** Tab → **Synergy Model**

**Voice prompt (speak aloud):** *"Build the synergy model. What is the maximum bid price?"*

**What appears:** 5-column bridge chart: Standalone Value → Synergy NPV → Total Acquisition Value → QoE + Debt-like deductions → Adjusted Max Bid. Opening bid recommendation. Synergy items table.

**What you say:**

> "Now we can answer the most important question in any M&A: what is the most we should pay? Standalone value — what the asset is worth without synergies — is around AEDm 3,800. Add the synergy NPV — cross-sell to our existing tenant base, procurement savings, opex efficiencies — and total acquisition value is ~AEDm 3,950. Deduct the QoE adjustment and debt-like items, and the adjusted maximum bid is AEDm 3,668."

> "The system recommends opening at 12% below that, giving us negotiating headroom. That's the number you put in the term sheet."

**What you click:** **DD Checklist** button (in QoE tab)

**What appears:** Due diligence checklist with 16 checks across Financial, Legal, Technical, Commercial — status badges, risk ratings, blocking items flagged in red.

**What you say:**

> "One blocking item: CTO retention is only on a 12-month lock-up. That's a closing condition."

**CFO takeaway:** EBITDA is real after normalisation. Maximum bid is AEDm 3,668. One blocking item in DD.

---

### Act 5 — Lock It Down (3 min)

**Tabs:** Evidence Chain → Approval Gate

#### Step 1 — Evidence chain

**What you click:** Tab → **Evidence Chain**

**Voice prompt (speak aloud):** *"Build the evidence chain — trace every number back to its source."*

**What appears:** List of every metric produced this session — each tagged with tool name, timestamp, scenario, and traceable badge. Traceability score. Gap flags for any missing metrics.

**What you say:**

> "Every number in this deck is traceable back to a specific tool call with a timestamp and scenario flag. This is the evidence chain. Before we freeze, we want all metrics traced — no gaps."

#### Step 2 — Freeze the gate

**What you click:** Tab → **Approval Gate**

**Voice prompt (speak aloud):** *"Freeze the approval gate as IC-v1.0."*

**What appears:** FROZEN badge appears. Gate version, timestamp, SHA-256 hash digest in monospace. Metric snapshot (IRR, NPV, EV, max bid, etc.) in read-only table.

**What you say:**

> "The gate is now frozen. That hash — that 16-character string — is a fingerprint of every metric in this session. If any number changes, the hash changes. You share this hash in the covering letter to the Investment Committee. If someone claims a number was different in the meeting, you can verify it in two seconds."

> "This is defensible in audit. It doesn't rely on a spreadsheet that someone could have edited after the meeting."

#### Step 3 — Board memo

**What you click:** **Generate Memo** button

**What appears:** 9-section Investment Committee memo: Executive Summary, Transaction Overview, Valuation Summary, Build vs Buy Rationale, QoE, Synergy Analysis, Risk & Sensitivities, Approval Gate, Recommended Resolution.

**What you say:**

> "And here's the IC memo — generated from the frozen gate, not from live state. Nine sections, board-ready. The gate version and hash are stamped on it. This is what you send to committee. Total time from opening the tool to IC memo: under 25 minutes."

**CFO takeaway:** Every number is hashed and frozen. The IC memo writes itself.

---

### Closing — So what? (1 min)

**What you say:**

> "What we've just done in 23 minutes would typically take a finance team two to three weeks: build a valuation model, run a build vs buy, compile M&A comps, normalise EBITDA, model synergies, run DD, write the IC memo, and make it audit-safe."

> "The Co-Pilot doesn't replace your finance team. It removes the time they spend on assembling information and lets them spend it on judgment — which is the only thing AI can't do yet."

> "We think this is the right prototype for the IC presentation. The next step is to point it at real DAMAC data and connect it to the actual model. Questions?"

---

## Voice demo moments — cheat sheet

These are the three moments most likely to impress in a short demo. Memorise the exact phrases.

| Moment | Exact words to speak | What happens |
|--------|---------------------|--------------|
| Football field | *"Show me the football field across all four valuation methods."* | SVG chart renders with 4 method bars and consensus band |
| Build vs Buy | *"Compare build versus buying for AEDm 1,600."* | Cards update, recommendation may flip |
| Freeze gate | *"Freeze the approval gate as IC-v1.0."* | FROZEN badge + hash digest appear live |

---

## If something goes wrong (backup)

- If voice is not connected (no API key): use the **quick prompt buttons** in the voice drawer — each one is a pre-typed equivalent
- If a tab shows blank: click the button inside it (e.g. "Run Analysis", "Build WACC") — same trigger, no voice needed
- If the server is slow: the finance engine is client-side JS — results appear immediately once the JS runs; latency is only from the voice token fetch, not the computation

---

## Setup checklist (before the demo)

- [ ] Server running: `node server.js` in `e:\17_Tiger\003_damac_valuation`
- [ ] Browser open at `http://localhost:3000/v02/index.html`
- [ ] OpenAI API key entered (click "API Key" top right)
- [ ] Test mic: click mic button, say something, confirm transcript appears
- [ ] Run football field once so the EV KPI strip is populated before the meeting starts
- [ ] Have v01 at `http://localhost:3000/` ready in a second tab if asked
