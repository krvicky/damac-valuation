# DAMAC CFO Finance Co-Pilot v02 — Integration Handoff

> **This document is written for Claude Code.** If you are a developer or an AI assistant helping with integration, read this first before touching any file.

---

## What this is

A **CFO Finance Co-Pilot** built for DAMAC Properties — specifically a data-center M&A valuation assistant. It lets a user (or CFO) ask voice questions and receive real-time financial analysis: IRR, NPV, multi-method enterprise valuation (football field), Build vs Buy comparison, M&A precedent comps, quality of earnings, synergy modelling, due diligence checklist, and an IC board memo with a hash-locked approval gate.

**Technology:**
- Frontend: vanilla HTML + ES modules — **no build step, no npm install needed**
- Backend: single `server.js` file, Node.js ≥ 22, **zero external dependencies**
- Voice: OpenAI Realtime API over WebRTC (requires `OPENAI_API_KEY`)
- Finance engine: 100% client-side deterministic JavaScript — no database, no LLM for calculations

**The target module to embed is `public/v02/index.html`.** Everything else is a dependency or the original v01 version (leave v01 untouched).

---

## File map

```
damac-valuation/
  server.js                  ← Node.js HTTP server. Contains the /api/v02/realtime-token
  │                            route that the frontend calls to start a voice session.
  │                            Add this route (or proxy it) in the master app's backend.
  package.json               ← "type": "module", Node ≥22, no npm dependencies
  │
  public/
    config.js                ← Exports API_BASE: empty string on localhost, full Render.com
    │                          URL in production. Update this if deploying under a new domain.
    finance.js               ← v01 finance engine — 14 tools. DO NOT MODIFY.
    styles.css               ← Base stylesheet used by both v01 and v02.
    index.html               ← v01 app entry point. Leave untouched.
    app.js                   ← v01 app logic. Leave untouched.
    │
    v02/                     ← THE MODULE TO INTEGRATE
      index.html             ← v02 entry point. Embed this as the tab.
      app.v02.js             ← All app logic: voice loop, state, render functions, 
      │                        tool handlers, tab navigation, event listeners.
      finance.v02.js         ← 27 finance tools (re-exports all 14 from ../finance.js
      │                        and adds 13 new ones: valuation, comps, QoE, synergies,
      │                        evidence chain, approval gate, board memo).
      styles.v02.css         ← v02 styles. Starts with @import "../styles.css".
```

---

## Dependency chain — CRITICAL

The v02 files use relative paths that assume `public/v02/` sits exactly one level below `public/`. If you move the files, these three imports must be updated:

| File | Import | Resolves to |
|------|--------|-------------|
| `public/v02/styles.v02.css` | `@import "../styles.css"` | `public/styles.css` |
| `public/v02/finance.v02.js` | `export * from "../finance.js"` | `public/finance.js` |
| `public/v02/app.v02.js` | `import { API_BASE } from "../config.js"` | `public/config.js` |

**Do not move these files without updating the three imports above.**

---

## Backend requirement

The v02 frontend makes one server call on voice start:

```
GET /api/v02/realtime-token
```

This is handled by `createRealtimeTokenV2()` in `server.js` (~line 130). It:
1. Reads `OPENAI_API_KEY` from env (or `X-OpenAI-Key` request header as fallback)
2. Calls the OpenAI Realtime API to create a client secret
3. Returns the session token to the browser

**What the master app's backend must do:**
- Option A: Run `server.js` as-is alongside the master app (different port, proxy requests)
- Option B: Copy the `createRealtimeTokenV2` function and its route into the master app's existing HTTP server. Also copy the import at the top of `server.js`:
  ```javascript
  import { realtimeFinanceToolsV2, sessionInstructionsV2 } from "./public/v02/finance.v02.js";
  ```

**Environment variable:**
```
OPENAI_API_KEY=sk-...
```
If not set server-side, the user can enter their own key in the browser via the "API Key" button (stored in sessionStorage only, never sent to your server).

---

## Integration options

### Option A — iframe (recommended, fastest)

Deploy this project and embed it as an iframe inside any master app tab:

```html
<iframe
  src="https://your-deployed-url/v02/index.html"
  style="width:100%; height:100vh; border:none;"
  allow="microphone"
></iframe>
```

> **Important:** Add `allow="microphone"` — the voice feature requires microphone access.  
> The iframe must be served from the same origin as the `/api/v02/realtime-token` route, or CORS must allow the iframe's origin.

Zero file coupling with the master app. All styles, tabs, and voice work out of the box.

### Option B — native file integration

If the master app needs the v02 UI to feel native (shared stylesheet, no iframe):

1. Copy `public/v02/` into the master project's static files directory
2. Copy `public/finance.js`, `public/styles.css`, `public/config.js` to maintain the same relative structure (one level above `v02/`), OR update the three relative imports in the v02 files to point to their new locations
3. Add the `/api/v02/realtime-token` route to the master app's backend (copy from `server.js`)
4. Update `config.js` to reflect the master app's production URL instead of the Render.com URL

---

## Running standalone (to verify it works before integrating)

```bash
# Requires Node.js v22 or higher
node server.js
# Server starts at http://localhost:3000
# v02 is at http://localhost:3000/v02/index.html
```

No `npm install` needed. Set `OPENAI_API_KEY` in your environment or enter it in the browser.

---

## What v02 contains (for context)

11 tabs, 27 voice-enabled finance tools:

| Tab | What it shows |
|-----|---------------|
| Investment Overview | Base case IRR, NPV, cash flow chart |
| IRR / CAPEX Scenarios | Base vs upside vs downside comparison |
| Risk Sensitivities | Sensitivity tornado with EV and IRR impact |
| Cash Flow Drilldown | Year-by-year cash flow table |
| Controls Risk | Financial controls framework |
| Valuation Methods | Football field chart — 4 methods, consensus EV |
| WACC / Capital | WACC build from components + EV sensitivity grid |
| Build vs Buy | Greenfield vs acquisition NPV/IRR comparison |
| Precedent Comps | 6 real M&A deals benchmarked against DAMAC implied |
| Quality of Earnings | EBITDA normalisation + debt-like items + DD checklist |
| Synergy Model | Synergy NPV, total acquisition value, maximum bid price |
| Evidence Chain | Every metric traced to its tool call |
| Approval Gate | Hash-locked frozen IC gate + 9-section board memo |

---

## Do not modify

- `public/finance.js` — the v01 finance engine. v02 re-exports from it; changes break both versions.
- `public/styles.css` — base stylesheet shared by v01 and v02.
- `public/app.js`, `public/index.html` — v01 app, untouched for separate demos.
